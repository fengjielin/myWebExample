$('#share').on('click', function () {
    $('#shareBox').show();
    $('#shade').show();
});
$('#close').on('click', function () {
    $('#shareBox').hide();
    $('#shade').hide();
});
